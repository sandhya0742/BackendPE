import java.sql.Date;

public class UserModel {

    private int userId;
    private boolean flag;
    private String userPassword;
    private String email;   
    private int buildingId;
    private Date lastPasswordChangedDate;
 
	public UserModel() {
		// TODO Auto-generated constructor stub
	}

}
