package com.arshaa.exceptions;

public class EmailNotFoundException extends Exception{

	public EmailNotFoundException(String msg) {
		super(msg);
	}
}
