package com.arshaa.model;

public class UserStatus {

    private boolean loginStatus;

	public boolean isLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(boolean loginStatus) {
		this.loginStatus = loginStatus;
	}

	public UserStatus() {
		// TODO Auto-generated constructor stub
	}

}
